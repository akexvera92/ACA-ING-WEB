const express = require("express");
const path = require('path');
const mysql = require("mysql2");
const accountSid = 'AC9271ed8f61947fc686c785ac36bf9831';
const authToken = '3d40c9d666af3a5d366693d48477db9a'
const client = require('twilio')(accountSid, authToken); // Inicialización del cliente Twilio

const app = express(); // Creación de la aplicación Express

// Configuración de conexión a la base de datos MySQL
let conexion = mysql.createConnection({
    host: "localhost",
    port: "3306",
    database: "INGWEB",
    user: "root",
    password: "ensalada22"
});

app.set("view engine", "ejs"); // Configuración del motor de vistas EJS
app.use(express.json()); // Middleware para parsear JSON en las solicitudes
app.use(express.urlencoded({ extended: false })); // Middleware para parsear datos de formularios URL-encoded

// Ruta principal que renderiza el formulario de registro
app.get("/", function (req, res) {
    res.render("formulario");
});

const moment = require('moment'); // Importación de Moment.js para manejo de fechas y horas

// Ruta para manejar la validación y registro de citas
app.post("/validar", function (req, res) {
    const datos = req.body; // Obtención de datos del formulario
    console.log(datos);

    let nombre = datos.nombre;
    let correo = datos.correo_electronico;
    let telefono = datos.telefono;
    let fecha = datos.fecha;
    let hora = datos.hora;
    let ubicacion = datos.ubicacion;

    // Formatear fecha para MySQL (YYYY-MM-DD)
    let fechaMySQL = fecha;

    // Verificar y convertir hora usando moment.js
    let horaMoment = moment(hora, 'HH:mm', true); // Parse strict (true)
    if (!horaMoment.isValid()) {
        console.log("Hora no válida:", hora);
        return res.status(400).json({ success: false, message: "La hora proporcionada no es válida." });
    }

    let horaFormateada = horaMoment.format('HH:mm');

    // Calcular la hora mínima permitida para la nueva cita
    let horaNueva = moment(horaFormateada, 'HH:mm');
    let horaMinima = moment(horaNueva).subtract(3, 'hours');

    console.log("Hora nueva:", horaNueva.format('HH:mm'));
    console.log("Hora mínima permitida:", horaMinima.format('HH:mm'));

    // Consulta para verificar si hay citas cercanas
    let consulta = `SELECT COUNT(*) AS count FROM citas 
                    WHERE fecha = ? 
                    AND (
                        (hora >= ? AND hora <= ?) OR
                        (hora <= ? AND hora >= ?)
                    )`;

    // Ejecución de la consulta en la base de datos
    conexion.query(consulta, [fechaMySQL, horaMinima.format('HH:mm:ss'), horaNueva.format('HH:mm:ss'), horaMinima.format('HH:mm:ss'), horaNueva.format('HH:mm:ss')], function (error, results) {
        if (error) {
            throw error; // Manejo de errores de consulta
        }

        // Verificar si hay citas cercanas
        if (results && results.length > 0 && results[0].count > 0) {
            console.log("Lo siento, no es posible agendar esta cita debido a que ya hay una programada muy pronto.");
            return res.status(400).json({ success: false, message: "Lo siento, no es posible agendar esta cita debido a que ya hay una programada muy pronto." });
        }

        // No hay citas cercanas, proceder con la inserción
        let registrar = `INSERT INTO citas(nombre, correo_electronico, telefono, fecha, hora, ubicacion) 
                         VALUES (?, ?, ?, ?, ?, ?)`;

        // Ejecución de la inserción en la base de datos
        conexion.query(registrar, [nombre, correo, telefono, fechaMySQL, horaNueva.format('HH:mm:ss'), ubicacion], function (error) {
            if (error) {
                throw error; // Manejo de errores de inserción
            }
            console.log("Datos ingresados correctamente");

            // Enviar mensaje de confirmación por WhatsApp
            const messageBody = `Estimado/a Julia Storm,Te informamos que la cita para ${nombre} está programada para el ${fecha} a las ${horaFormateada} en ${ubicacion}. Si necesitas contactarnos, puedes hacerlo a través de correo electrónico (${correo}) o por teléfono (${telefono}).`;

            // Envío de mensaje por WhatsApp usando Twilio
            client.messages.create({
                body: messageBody,
                from: 'whatsapp:+14155238886',
                to: 'whatsapp:+573114699577'
            })
            .then(message => {
                console.log(message.sid); // Confirmación de envío exitoso en consola
                // Envío de respuesta al cliente
                res.status(200).json({ success: true, message: "¡Cita programada con éxito! Los datos se han ingresado correctamente. ¡Gracias!" });
            })
            .catch(error => {
                console.error(error); // Manejo de errores al enviar mensaje por WhatsApp
                res.status(500).json({ success: false, message: "Hubo un error al enviar el mensaje de confirmación." });
            });
        });
    });
});


// Iniciar el servidor en el puerto 3000
app.listen(3000, function () {
    console.log("Servidor creado en http://localhost:3000");
});
